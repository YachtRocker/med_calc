from medcalclib import myfunctions

def  test_minuteventilation():
    assert myfunctions.minuteventilation(22, 325)

