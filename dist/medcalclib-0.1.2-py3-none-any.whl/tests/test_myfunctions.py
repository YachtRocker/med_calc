from medcalclib import myfunctions

def  test_minuteventilation():
    assert myfunctions.minuteVentilation(22, 325)

